import cv2
import sqlite3
import numpy as np

faceDetect=cv2.CascadeClassifier('haarcascade_frontalface_default.xml');
cam=cv2.VideoCapture(0);

def insertOrUpdate(Id,name,age,gender,department):
    conn=sqlite3.connect("FaceBase.db")
    cmd="SELECT * FROM people WHERE ID="+str(Id)
    cursor=conn.execute(cmd)
    isRecordExist=0
    for row in cursor:
        isRecordExist=1
    if(isRecordExist==1):
        cmd="UPDATE people SET Name=' "+str(name)+" ',Age=' "+str(age)+" ',Gender=' "+str(gender)+" ',Department=' "+str(department)+" ' WHERE ID="+str(Id)
    else:
        cmd="INSERT INTO people(ID,Name,Age,Gender,Department) VALUES("+str(Id)+","+str(name)+","+str(age)+","+str(gender)+","+str(department)+")"
    conn.execute(cmd)
    conn.commit()
    conn.close()

id=raw_input('enter user id:')
name=raw_input('enter user name:')
age=raw_input('enter user age:')
gender=raw_input('enter user gender:')
department=raw_input('enter user department:')
insertOrUpdate(id,name,age,gender,department)
sampleNum=0;
while(True):
    ret,img=cam.read();
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    faces=faceDetect.detectMultiScale(gray,1.3,5);
    for(x,y,w,h) in faces:
        sampleNum=sampleNum+1;
        cv2.imwrite("dataSet/User."+str(id)+"."+str(sampleNum)+".jpg",gray[y:y+h,x:x+w])
        cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
        cv2.waitKey(100);
    cv2.imshow("Face",img);
    cv2.waitKey(1);
    if(sampleNum>20):
        break
cam.release()
cv2.destroyAllWindows()
